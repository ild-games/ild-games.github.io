var checkpointDrawable = {
    "topDrawable": {
        "__cpp_type": "ild::ContainerDrawable",
        "key": "ContainerDrawable",
        "inactive": false,
        "renderPriority": 3,
        "scale": {
            "x": 1,
            "y": 1
        },
        "rotation": 0,
        "anchor": {
            "x": 0,
            "y": 0
        },
        "priorityOffset": 0,
        "type": 1,
        "drawables": [
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "nonvisited",
                "inactive": false,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "visited",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "activation",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable31",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable32",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable33",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable34",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable35",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable36",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable37",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable38",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable39",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable40",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable41",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable42",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable43",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable44",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable45",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable46",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable47",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable48",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable49",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable50",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_2048",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            }
        ]
    }
}

module.exports = function (tools) {
    return tools.entityMigration(function (entity) {
        if (entity.checkpoint) {
            var newEntity = Object.assign({}, entity, { drawable: checkpointDrawable });
            return newEntity;
        } else {
            return entity;
        }
    });
}