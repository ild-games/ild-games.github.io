var playerDrawable = {
    "topDrawable": {
        "__cpp_type": "ild::ContainerDrawable",
        "key": "topDrawable",
        "inactive": false,
        "renderPriority": 100,
        "scale": {
            "x": 1,
            "y": 1
        },
        "rotation": 0,
        "priorityOffset": 0,
        "type": 1,
        "drawables": [
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallLanding",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.08,
                    "y": 0.1
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "landing",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "jump",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallJump",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.1,
                    "y": 0.1
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f11_128_128_wallJump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.08,
                    "y": 0.1
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "idle",
                "inactive": false,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeath",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.07,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeath",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.09,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeathIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.07,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeathIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.09,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            }
        ],
        "anchor": {
            "x": 0.25,
            "y": -0.04
        }
    }
};

var spawnerDrawable = {
    "topDrawable": {
        "__cpp_type": "ild::ContainerDrawable",
        "key": "topDrawable",
        "inactive": false,
        "renderPriority": 100,
        "scale": {
            "x": 1,
            "y": 1
        },
        "rotation": 0,
        "priorityOffset": 0,
        "type": 1,
        "drawables": [
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallLanding",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.08,
                    "y": 0.1
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f6_128_128_wallLanding",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "landing",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f7_128_204_landing",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "jump",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallJump",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f9_128_204_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.08,
                    "y": 0.1
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_128_wallIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_airIdle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "idle",
                "inactive": false,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f12_128_204_idle",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeath",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.07,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeath",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.09,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeathIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.07,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f20_128_128_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeathIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.09,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f26_128_204_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            }
        ],
        "anchor": {
            "x": 0.25,
            "y": -0.04
        }
    }
};

module.exports = function (tools) {
    return tools.entityMigration(function (entity, entityKey) {
        if (entityKey === "player") {
            return Object.assign({}, entity, { drawable: playerDrawable });
        }
        if (entityKey === "follower" || entityKey === "spawner") {
            return Object.assign({}, entity, { drawable: spawnerDrawable });
        }
        return entity;
    });
}
