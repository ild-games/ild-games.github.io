var airDeathIdle = {
    "__cpp_type": "ild::AnimatedDrawable",
    "key": "airDeathIdle",
    "inactive": true,
    "renderPriority": 0,
    "scale": {
        "x": 1,
        "y": 1
    },
    "rotation": 0,
    "anchor": {
        "x": 0,
        "y": 0
    },
    "priorityOffset": 0,
    "duration": 0.03,
    "frames": [
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable33",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4096,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable34",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4224,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable35",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4352,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable36",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4480,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable37",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4608,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable38",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4736,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable39",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4864,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable40",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 4992,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable41",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 5120,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable42",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 5248,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable43",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 5376,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable44",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 5504,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        },
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable45",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/AirDeath3Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 5632,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        }
    ]
}

var groundDeathIdle = {
    "__cpp_type": "ild::AnimatedDrawable",
    "key": "groundDeathIdle",
    "inactive": true,
    "renderPriority": 0,
    "scale": {
        "x": 1,
        "y": 1
    },
    "rotation": 0,
    "anchor": {
        "x": 0.17,
        "y": 0
    },
    "priorityOffset": 0,
    "duration": 0.03,
    "frames": [
        {
            "__cpp_type": "ild::ImageDrawable",
            "key": "ImageDrawable20",
            "inactive": false,
            "renderPriority": 0,
            "scale": {
                "x": 1,
                "y": 1
            },
            "rotation": 0,
            "anchor": {
                "x": 0,
                "y": 0
            },
            "priorityOffset": 0,
            "type": 2,
            "textureKey": "texture/player/GroundDeath2Render_00000",
            "isWholeImage": false,
            "textureRect": {
                "position": {
                    "x": 2432,
                    "y": 0
                },
                "dimension": {
                    "x": 128,
                    "y": 128
                }
            },
            "isTiled": false,
            "tiledArea": {
                "x": 100,
                "y": 100
            }
        }
    ]
}

module.exports = function (tools) {
    return tools.entityMigration(function (entity) {
        if (entity.playerDeath) {
            entity.drawable.topDrawable.drawables.push(groundDeathIdle);
            entity.drawable.topDrawable.drawables.push(airDeathIdle);
            return entity;
        } else {
            return entity;
        }
    });
}
