module.exports = function (tools) {
    return tools.attributeMigration("cameraActor", function (cameraActor) {
        if (!cameraActor.depth) {
            cameraActor.depth = 1;
        }

        return cameraActor;
    });
}