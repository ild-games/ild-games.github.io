var checkpointCollision = {
    "dimension": {
        "dimension": {
            "x": 64,
            "y": 512
        },
        "position": {
            "x": 0,
            "y": 0
        },
        "rotation": 0
    },
    "bodyType": "none",
    "collisionType": "checkpoint",
    "oneWayNormal": {
        "x": 0,
        "y": 0
    },
    "anchor": {
        "x": 0,
        "y": 0.75
    }
}
var checkpointDrawable = {
    "topDrawable": {
        "__cpp_type": "ild::ContainerDrawable",
        "key": "ContainerDrawable",
        "inactive": false,
        "renderPriority": 3,
        "scale": {
            "x": 1,
            "y": 1
        },
        "rotation": 0,
        "anchor": {
            "x": 0,
            "y": -0.28
        },
        "priorityOffset": 0,
        "type": 1,
        "drawables": [
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "nonvisited",
                "inactive": false,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-not-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "visited",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "activation",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.05,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "not-active-1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-not-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "not-active-2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-not-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "not-active-3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-not-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "not-active-4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-not-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "not-active-5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-not-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "active-10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/challenge-mode/checkpoint/checkpoint-active",
                        "isWholeImage": true,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 0,
                                "y": 0
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            }
        ]
    }
};

module.exports = function (tools) {
    return tools.entityMigration(function (entity, entityKey) {
        if (entity.checkpoint) {
            return Object.assign({}, entity, { 
                drawable: checkpointDrawable,
                collision: checkpointCollision
            });
        }
        return entity;
    });
}
