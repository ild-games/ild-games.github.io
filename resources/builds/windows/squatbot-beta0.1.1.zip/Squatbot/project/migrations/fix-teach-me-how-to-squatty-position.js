module.exports = function(tools) {
    return function(map) {
        let migration = tools.entityMigration(function (entity) {
            if (map.key !== "TeachMeHowToSquatty") {
                return entity;
            }

            if (map.dimension.x != 12000) {
                map.dimension.x = 12000;
            }
            if (map.dimension.y != 5000) {
                map.dimension.y = 5000;
            }
            map.dimension.x = 12000;
            map.dimension.y = 5000;
            
            if (entity.drawable && entity.drawable.camEntity === "hudCamera") {
                return entity;
            }
            
            if (entity.position && entity.position.position) {
                entity.position.position.x += 6080;
                entity.position.position.y += -4160;
            }
            return entity;
        });
        return migration(map);
    }
}