var playerDrawable = {
    "topDrawable": {
        "__cpp_type": "ild::ContainerDrawable",
        "key": "topDrawable",
        "inactive": false,
        "renderPriority": 100,
        "scale": {
            "x": 1,
            "y": 1
        },
        "rotation": 0,
        "priorityOffset": 0,
        "type": 1,
        "drawables": [
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeath",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "inactive": true,
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeathIdle",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "textureKey": "texture/player/skins/normal/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0,
                        "inactive": false
                    }
                ],
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "inactive": true,
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallLanding",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallJump",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallIdle",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "textureKey": "texture/player/skins/normal/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "idle",
                "inactive": false,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable31",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable32",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable33",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable34",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable35",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable36",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable37",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable38",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "landing",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "idleAir",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "jump",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeathIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.1,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeath",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.1,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/player/skins/normal/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            }
        ],
        "anchor": {
            "x": 0.25,
            "y": -0.04
        }
    }
}

var spawnerDrawable = {
    "topDrawable": {
        "__cpp_type": "ild::ContainerDrawable",
        "key": "topDrawable",
        "inactive": false,
        "renderPriority": 100,
        "scale": {
            "x": 1,
            "y": 1
        },
        "rotation": 0,
        "priorityOffset": 0,
        "type": 1,
        "drawables": [
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeath",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "inactive": true,
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "groundDeathIdle",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "textureKey": "texture/squatty-spawner/f21_groundDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0,
                        "inactive": false
                    }
                ],
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "inactive": true,
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallLanding",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallJump",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 384
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "wallIdle",
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 128
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "textureKey": "texture/squatty-spawner/f30_wall",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 256
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        },
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "rotation": 0
                    }
                ],
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "rotation": 0
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "idle",
                "inactive": false,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable31",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable32",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable33",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable34",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable35",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable36",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable37",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable38",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 816
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "landing",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "idleAir",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "jump",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.03,
                    "y": 0.07
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f39_jump",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeathIdle",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.1,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 408
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 612
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "airDeath",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0.1,
                    "y": 0.3
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "textureKey": "texture/squatty-spawner/f28_airDeath",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 204
                            },
                            "dimension": {
                                "x": 128,
                                "y": 204
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            }
        ],
        "anchor": {
            "x": 0.25,
            "y": -0.04
        }
    }
}

/* we are exporting a function that takes tools and returns a function
   the function it returns takes a map does stuff to it, and returns a map */

module.exports = function (tools) {
    return function(map) {
        let entityMigration = tools.entityMigration(function (entity, entityKey) {
            if (entity.playerDeath) {
                if (entity.spawnFollower || entityKey === "spawner") {
                    return Object.assign({}, entity, { drawable: spawnerDrawable });
                } else {
                    return Object.assign({}, entity, { drawable: playerDrawable });
                }
            } else {
                return entity;
            }
        });
        let entitiesMigratedMap = entityMigration(map);
        let newAssets = entitiesMigratedMap.assets;
        for (let asset of newAssets) {
            asset.key = asset.key.split("_Flat_00000")[0];
        }
        return Object.assign({}, entitiesMigratedMap, { assets: newAssets });
    };
}
