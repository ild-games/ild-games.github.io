var checkpointDrawable =   {                  
    "topDrawable": {

        "__cpp_type": "ild::ContainerDrawable",
        "key": "ContainerDrawable",
        "inactive": false,
        "renderPriority": 3,
        "scale": {
            "x": 1,
            "y": 1
        },
        "rotation": 0,
        "anchor": {
            "x": 0,
            "y": 0
        },
        "priorityOffset": 0,
        "type": 1,
        "drawables": [
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "nonvisited",
                "inactive": false,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.02,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2048,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2176,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2304,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2432,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2560,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2688,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2816,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2944,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3072,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3200,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3328,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3456,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3584,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30nonvisited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3712,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "visited",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.025,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2048,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2176,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2304,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2432,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2560,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2688,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2816,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2944,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3072,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3200,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3328,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3456,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3584,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f30visited_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3712,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            },
            {
                "__cpp_type": "ild::AnimatedDrawable",
                "key": "activation",
                "inactive": true,
                "renderPriority": 0,
                "scale": {
                    "x": 1,
                    "y": 1
                },
                "rotation": 0,
                "anchor": {
                    "x": 0,
                    "y": 0
                },
                "priorityOffset": 0,
                "duration": 0.03,
                "frames": [
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable1",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 0,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable2",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 128,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable3",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 256,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable4",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 384,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable5",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 512,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable6",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 640,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable7",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 768,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable8",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 896,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable9",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1024,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable10",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1152,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable11",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1280,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable12",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1408,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable13",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1536,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable14",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1664,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable15",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1792,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable16",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 1920,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable17",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2048,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable18",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2176,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable19",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2304,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable20",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2432,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable21",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2560,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable22",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2688,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable23",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2816,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable24",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 2944,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable25",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3072,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable26",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3200,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable27",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3328,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable28",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3456,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable29",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3584,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable30",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3712,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable31",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3840,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable32",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 3968,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable33",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4096,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable34",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4224,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable35",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4352,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable36",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4480,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable37",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4608,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable38",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4736,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable39",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4864,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable40",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 4992,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable41",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 5120,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable42",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 5248,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable43",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 5376,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable44",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 5504,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable45",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 5632,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable46",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 5760,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable47",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 5888,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable48",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 6016,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable49",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 6144,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    },
                    {
                        "__cpp_type": "ild::ImageDrawable",
                        "key": "ImageDrawable50",
                        "inactive": false,
                        "renderPriority": 0,
                        "scale": {
                            "x": 1,
                            "y": 1
                        },
                        "rotation": 0,
                        "anchor": {
                            "x": 0,
                            "y": 0
                        },
                        "priorityOffset": 0,
                        "type": 2,
                        "textureKey": "texture/checkpoints/f50activation_00000",
                        "isWholeImage": false,
                        "textureRect": {
                            "position": {
                                "x": 6272,
                                "y": 0
                            },
                            "dimension": {
                                "x": 128,
                                "y": 128
                            }
                        },
                        "isTiled": false,
                        "tiledArea": {
                            "x": 100,
                            "y": 100
                        }
                    }
                ]
            }
        ]
    }
};

var checkpointCollision = {
    "dimension": {
        "dimension": {
            "x": 64,
            "y": 512
        },
        "position": {
            "x": 0,
            "y": 0
        },
        "rotation": 0
    },
    "bodyType": "none",
    "collisionType": "checkpoint",
    "oneWayNormal": {
        "x": 0,
        "y": 0
    },
    "anchor": {
        "x": -0.5,
        "y": 0.75
    }
};

module.exports = function (tools) {
    return tools.entityMigration(function(entity) {
        if (entity.checkpoint) { 
            var newEntity = Object.assign({}, entity, { drawable: checkpointDrawable, collision: checkpointCollision});
            newEntity.position.position.y = newEntity.position.position.y - 64;
            return newEntity;
        } else {
            return entity;
        }
    });
}