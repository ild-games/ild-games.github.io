module.exports = function(tools) {
    return tools.entityMigration(function(entity) {
        if (entity.collision && (entity.collision.collisionType === "coin")) {
            entity.triggerDeath = {
                animationToWatch : "topDrawable"
            }
            delete entity.drawable.topDrawable.destroyEntityWhenFinished;
        }
        return entity;
    });
}