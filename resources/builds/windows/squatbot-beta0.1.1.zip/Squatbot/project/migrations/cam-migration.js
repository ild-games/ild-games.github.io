module.exports = function(tools) {
    return tools.entityMigration(function(entity) {
        if (entity.camera) {
            delete entity.camera.upperBound;
            delete entity.camera.lowerBound;
            entity.camera.upperBounds = {
                  x: 100000,
                  y: 100000
            };
            entity.camera.lowerBounds = {
                  x: -100000,
                  y: -100000
            };

        }
        return entity;
    });
}