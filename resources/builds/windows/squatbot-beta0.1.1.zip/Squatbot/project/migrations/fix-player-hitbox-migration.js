module.exports = function (tools) {
    return tools.entityMigration(function (entity, entityKey) {
        if (entityKey === "player" || entityKey === "follower" || entityKey === "spawner") {
            let drawable = entity.drawable;
            drawable.topDrawable.anchor.y = 0.008;
            let position = entity.position;
            position.position.y += 9;
            let collision = entity.collision;
            collision.dimension.dimension.x = 45;
            collision.dimension.dimension.y = 48;
            return Object.assign({}, entity, { 
                drawable,
                position,
                collision
            });
        }
        return entity;
    });
}
